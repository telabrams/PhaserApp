import { StoriesService } from './../../core/stories.service';
import { Router } from '@angular/router';
import { Component, Inject, OnInit, ViewChild} from '@angular/core';
import { MAT_DIALOG_DATA, MatDialog, MatDialogRef } from '@angular/material';
import { AuthService } from '../../core/auth.service';
import { Observable } from 'rxjs/Observable';
import { map } from 'rxjs/operator/map';

@Component({
    selector: 'app-storydialog-component',
    templateUrl: 'dialog.html',
})
export class StoryDialogComponent implements OnInit {
    profileId: any;
    @ViewChild('ninjablock') ninjablock;

    constructor(
        @Inject(MAT_DIALOG_DATA) public data: any,
        public dialogRef: MatDialogRef<StoryDialogComponent>,
        public storiesSrv: StoriesService,
        private router: Router,
        private auth: AuthService) {
    }

    ngOnInit() {
    }

    hover() {
      this.ninjablock.nativeElement.style.cssText = "opacity: 1; visibility: visible; transform: translateY(0)";
    }

    unhover() {
      this.ninjablock.nativeElement.style.cssText = "opacity: 0; visibility: collapse; transform: translateY(47px)";
    }


    viewProfile(profileId) {
        console.log(profileId)
        this.router.navigate(['/profile/' + profileId])
            .then(() => {
                this.dialogRef.close();
            })
    }

    voteStory(storyId) {
        console.log(storyId)
        this.storiesSrv.getSpecificStory(storyId)
            .subscribe((data) => {
                if (!data) { console.log('error voting') } else {
                    this.storiesSrv.voteStory(data.objectID).subscribe(vote => {
                        this.data.dialogFooter.votes = data.votes;
                        this.data.dialogFooter.votes++;
                    });
                }
                return data.votes;
            })
    }
}
