import { AuthService } from './../core/auth.service';
import { Component, OnInit, HostListener, ViewChild, AfterViewChecked, Injectable, Input, Output, EventEmitter, OnChanges, AfterViewInit } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { StoriesService } from '../core/stories.service';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { MatTooltipModule, MatDialog, MAT_DIALOG_DATA } from '@angular/material';
import { FilterPipe } from '../filter.pipe';
import { AnimationService } from '../core/animation.service';
import { AsyncPipe } from '@angular/common/src/pipes';
import { TimeAgoPipe } from 'time-ago-pipe';
import { FormsService } from '../core/forms.service';
import { FormGroup, FormControl, ReactiveFormsModule } from '@angular/forms';
import { DatePicker } from '../core/datepicker.service';
import { StoryDialogComponent } from './dialog/dialog';



@Component({
  selector: 'app-discover',
  templateUrl: './discover.component.html',
  styleUrls: ['./discover.component.scss'],
  providers: [StoriesService, AnimationService, FormsService, DatePicker]
})

export class DiscoverComponent implements OnInit, OnChanges, AfterViewChecked, AfterViewInit {


  allStoryData: any;
  scrolling: boolean;
  modalActive = false;
  specificStoryData: Array<any>;

  hitsArray: Array<Object> = [];

  // Story-vars
  page: any = 0;
  feed: string = 'curated';
  hits: string = '9';
  storyId: any = '';
  licenseType: any = '';
  query: any = '';
  verifiedType: any = '';
  mediaType: any = '';
  startDate: any = '';
  endDate: any = '';

  // Radiobuttons
  mediaRadio: string = '';
  licenseRadio: string = '';
  verifiedRadio: string = '';
  // Global inputvalues for Radiobuttons
  @Input() all: string; image: string; video: string; true: boolean; false: boolean;
  // Button-event payload
  @Output() mediaButtonSelectionChange: EventEmitter<string> = new EventEmitter<string>();
  @Output() licenseButtonSelectionChange: EventEmitter<string> = new EventEmitter<string>();
  @Output() verifiedButtinSelectionChange: EventEmitter<string> = new EventEmitter<string>();


  // Loading?
  finished: boolean = false;
  isLoading: boolean = false;


  // Datepicker
  @ViewChild('hiddenInput') hiddenInput;
  dateModel: any = '';
  date1: any = '';
  date2: any = '';

  constructor(
    private storyDialog: MatDialog,
    private auth: AuthService,
    private date: DatePicker,
    private forms: FormsService,
    private animation: AnimationService,
    private storiesService: StoriesService,
    private route: ActivatedRoute,
    private router: Router) {
    this.date = date;
  }
  ngAfterViewChecked() {
    this.animation.ngOnInit();
  }

  ngAfterViewInit() {

  }

  ngOnChanges() {
    while (this.storiesService.isLoading === true) {
      this.isLoading = true;
    }
    if (this.storiesService.isLoading === false) {
      this.isLoading = false;
    }
  }

  private getSpecificStory(story, type) { //Only for open modal
    this.storiesService.getSpecificStory(story.objectID)
      .subscribe(
      (data) => {
        this.specificStoryData = data;
        this.storyId = data.objectID;
        console.log(this.specificStoryData);
        this.storyDialog.open(StoryDialogComponent, {
          data: { // <- data = (modalobject) = data.dataObjectName.var
            storyDialogImage: data.storyPreview, // <- data = API story object
            storyId: data.objectID,
            storyType: type,
            profileId: data.profile.objectID,
            dialogFooter: {
              votes: data.votes,
              impressions: data.impressions,
              verify: data.isVerified,
              price: data.storyPrice,
            },
            dialogAuthor: {
              authorName: [data.profile.firstName + ' ' + data.profile.lastName],
              authorNick: data.profile.displayName,
              authorProfileImg: data.profile.userPicture,
              authorTags: [data.profile.isMedia, data.profile.isPress, data.profile.isProfessional],
              title: data.storyHeadline,
              date: data.uploadDate,
              location: [data.storyCity + ' ' + data.storyCountry]
            },
          }
        })
      })

  }

  ngOnInit() {
    this.isLoading = true;
    this.date.initDatePicker();
    this.mediaRadio = 'all'; this.licenseRadio = 'all'; this.verifiedRadio = 'all';
    this.mediaType = 'all'; this.licenseType = 'all'; this.verifiedType = 'all';

    this.forms.ngAfterViewChecked();
    this.route.params.subscribe(
      (params: Params) => {
        this.hitsArray = []; // upon refreshing, empty array
        this.feed = params['feed'];
        if (this.modalActive === true) {
          this.router.navigate(['discover' + this.feed + this.storyId])
        }
      }
    );
    this.hitsArray = [];
    this.getStories(this.page, this.hits, this.feed, this.mediaType, this.query, this.verifiedType, this.licenseType, this.startDate, this.endDate);
    this.isLoading = false;
  }

  sortDate($event) {
    let className = $event.target.className,
      tagName = $event.target.tagName,
      textContent = $event.target.textContent;
    className = className.split(' ')[0];
    setTimeout(() => {
      this.dateModel = this.hiddenInput.nativeElement.value;
      this.dateModel = this.dateModel.split('-');
      this.date1 = new Date(this.dateModel[0]).getTime();
      this.dateModel[1] !== undefined ? this.date2 = new Date(this.dateModel[1]).getTime() : this.date2 = new Date(this.dateModel[0]).getTime();
      if (!isNaN(this.date1) && className === 'ui-state-default' && tagName === 'A') {
        this.startDate = this.date1;
        this.endDate = this.date2;
        console.log(this.startDate, this.endDate);
        this.getStories(this.page, this.hits, this.feed, this.mediaType, this.query, this.verifiedType, this.licenseType, this.startDate, this.endDate);
      } else if (!isNaN(this.date1) && tagName === 'LI' && textContent !== 'Custom') {
        this.startDate = this.date1;
        this.endDate = this.date2;
        console.log(this.startDate, this.endDate);
        this.getStories(this.page, this.hits, this.feed, this.mediaType, this.query, this.verifiedType, this.licenseType, this.startDate, this.endDate);
      }
    }, 1)
  }

  sortMedia() {
    this.page = 0;
    this.hitsArray = [];
    this.mediaButtonSelectionChange.emit(this.mediaRadio);
    this.mediaType = this.mediaRadio;
    this.getStories(this.page, this.hits, this.feed, this.mediaType, this.query, this.verifiedType, this.licenseType, this.startDate, this.endDate);

  }

  sortLicense() {
    this.page = 0;
    this.hitsArray = [];
    this.licenseButtonSelectionChange.emit(this.licenseRadio);
    this.licenseType = this.licenseRadio;
    this.getStories(this.page, this.hits, this.feed, this.mediaType, this.query, this.verifiedType, this.licenseType, this.startDate, this.endDate);
  }

  sortVerification() {
    this.page = 0;
    this.hitsArray = [];
    this.verifiedButtinSelectionChange.emit(this.verifiedRadio);
    this.verifiedType = this.verifiedRadio;
    this.getStories(this.page, this.hits, this.feed, this.mediaType, this.query, this.verifiedType, this.licenseType, this.startDate, this.endDate);

  }

  private getStories(page, hits, feed, mediaType, query, verifiedType, licenseType, startDate, endDate) { // location (see docs)
    feed = this.route.params['feed'];
    this.hitsArray = [];
    if (this.page >= 0) {
      this.isLoading = true;
      this.storiesService.getStories(this.page, this.hits, this.feed, this.mediaType, this.query, this.verifiedType, this.licenseType, this.startDate, this.endDate)
        .subscribe(
        (data) => {
          // console.log(data);
          if (!data && data.hits.length <= 8 && data.hits.length !== 0) {
            this.finished = true;
            this.hitsArray = [];
            this.hitsArray.push.apply(this.hitsArray, data.hits)
            console.log('No hits')
          } else {
            this.allStoryData = data;
            console.log(this.allStoryData)
          }
          this.finished = true;
          this.isLoading = false;
        })
    }
  }

  // DER ER OGSÅ ÆNDRET I HTML!!!
  // private getStories(page, hits, feed, mediaType, query, verifiedType, licenseType, startDate, endDate) { // location (see docs)
  //   feed = this.route.params['feed'];
  //   this.hitsArray = [];
  //   if (this.page >= 0) {
  //     this.isLoading = true;
  //     this.storiesService.getStories(this.page, this.hits, this.feed, this.mediaType, this.query, this.verifiedType, this.licenseType, this.startDate, this.endDate)
  //       .subscribe(
  //       (data) => {
  //         // console.log(data);
  //         if (!data && data.hits.length <= 8 && data.hits.length !== 0) {
  //           this.finished = true;
  //           this.hitsArray = [];
  //           this.hitsArray.push.apply(this.hitsArray, data.hits)
  //           console.log('No hits')
  //         } else {
  //           this.finished = false;
  //           this.hitsArray = [];
  //           this.hitsArray.push.apply(this.hitsArray, data.hits)
  //           console.log(this.hitsArray)
  //         }
  //         this.finished = true;
  //         this.isLoading = false;
  //       })
  //   }
  // }

  viewProfile(profileId) {
    console.log(profileId);
    this.router.navigate(['/profile/' + profileId])
  }

  private vote(story) {
    if (!story.userVote) {
      this.storiesService.voteStory(story.objectID)
        .subscribe(
        (data) => {
          story.votes++; // api counter
          console.log(story.votes)
          story.userVote = true; // api call
        })
    } else if (story.userVote) {
      this.storiesService.unVoteStory(story.objectID)
        .subscribe(
        (data) => {
          story.votes--;
          console.log(story.votes)
          story.userVote = false;
        })
    }

  }

  getInitialFeed(feed) {
    this.isLoading = true;
    this.hitsArray = [];
    this.page = 0;
    this.feed = feed || this.feed; //for either html get or reset function
    this.getStories(this.page, this.hits, this.feed, this.mediaType, this.query, this.verifiedType, this.licenseType, this.startDate, this.endDate);
  }

  private clearAllFilters() {
    this.hitsArray = [];
    // location.reload();
    this.mediaRadio = 'all'; this.licenseRadio = 'all'; this.verifiedRadio = 'all';
    this.mediaButtonSelectionChange.emit(this.mediaRadio); this.licenseButtonSelectionChange.emit(this.licenseRadio); this.verifiedButtinSelectionChange.emit(this.verifiedRadio);
    this.mediaRadio = this.mediaType; this.verifiedRadio = this.verifiedType; this.licenseRadio = this.licenseType;

    this.page = 0, this.hits = '9', this.mediaType = 'all', this.query = '', this.verifiedType = 'all', this.licenseType = 'all', this.startDate = '', this.endDate = '';
    this.getStories(this.page, this.hits, this.feed, this.mediaType, this.query, this.verifiedType, this.licenseType, this.startDate, this.endDate);
  }

  onScroll() {
    this.scrolling = true;

    this.scrollStories()
  }

  private scrollStories() {
    // this.page++; // SCROLLING
    this.isLoading = true;
    this.hits += 9;
    this.getStories(this.page, this.hits, this.feed, this.mediaType, this.query, this.verifiedType, this.licenseType, this.startDate, this.endDate);
    console.log('Scrolling!')
  }

  // private scrollStories() {
  //   this.page++; // SCROLLING
  //   this.isLoading = true;
  //   if (this.page > 0) {
  //     console.log(this.page);
  //     this.storiesService.getStories(this.page, this.hits, this.feed, this.mediaType, this.query, this.verifiedType, this.licenseType, this.startDate, this.endDate)
  //       .subscribe(
  //       (data) => {
  //         console.log(data);
  //         if (!data || data.hits === 0 || data.hits.length === 0 || data.hits < 9) {
  //           this.isLoading = false;
  //           console.log('no more scrolling')
  //         } else {
  //           this.hitsArray.push.apply(this.hitsArray, data.hits)
  //           console.log(this.hitsArray);
  //         }
  //       })
  //     this.isLoading = false;
  //   }
  // }



}
